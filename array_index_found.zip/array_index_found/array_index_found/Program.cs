﻿using System;

namespace Array_found {
    class array_index {
        public static void Main(string[] args) {
            int[] array_no = { 20,50,70,90,110};

            Console.WriteLine(Array.IndexOf(array_no,50));
        }
    }
}

