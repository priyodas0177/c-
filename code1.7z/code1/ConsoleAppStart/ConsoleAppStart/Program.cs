﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppStart
{
    struct Point
    {
        public int x;
        public int y;

        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public void PrintPoint(string info)
        {
            Console.WriteLine("{2}:({0},{1})", this.x, this.y, info);
        }
    }

     class Program
    {
        static void Main(string[] args)
        {
            /*Point p1;
            p1.x = 10;
            p1.y = 20;
            Console.WriteLine("p1:({0},{1})", p1.x, p1.y);
            p1.PrintPoint("p1");*/

            /*Point p2 = p1;
            p2.x++;
            p2.y--;
            p2.PrintPoint("p2");
            p1.PrintPoint("p1");
            Console.WriteLine("p2:({0},{1})", p2.x, p2.y);
            Console.WriteLine("p1:({0},{1})", p1.x, p1.y);*/

            Point p3 = new Point();
            p3.x = 9;
            p3.y = -34;
            p3.PrintPoint("p3");

            //Point p4 = new Point(39, 4);
            //p4.PrintPoint("p4");

            //int[] ax = new int[4] { 10, 20, 30, 40 };
            //ax[0] = 100;

            //for (byte c = 0; c < ax.Length; c++)
            //{
            //    Console.Write("{0} ", ax[c]);

            //}
            //Console.WriteLine();

            //int d = 0;
            //while (d < 4)
            //{
            //    Console.Write("{0} ", ax[d]);
            //    d++;
            //}

            //foreach (int info in ax)
            //{
            //    Console.Write("{0} ", info);
            //}

            //Console.WriteLine();
            //int r = 4;
            //do
            //{
            //    Console.Write("{0}", r);
            //    r++;
            //}
            //while (r < 4);
            //Console.WriteLine();

            //int[,] bx = new int[3, 4] { { 1, 2, 3, 4 }, { 5, 6, 7, 8 }, { 9, 10, 11, 12 } };

            //int r = 0, c;
            //while (r < 3)
            //{
            //    c = 0;
            //    while (c < 4)
            //    {
            //        Console.Write("{0} ", bx[r, c]);
            //        c++;
            //    }
            //    Console.WriteLine();
            //    r++;
            //}

            //foreach(int info in bx)
            //    Console.Write("{0} ", info);
            //Console.WriteLine();

            //int[,,] cx = new int[3, 4, 3];
            //int[,,,,] dx = new int[4, 3, 4, 2, 1];

            //jagged array

            /* int[][] jx = new int[4][];
             jx[0] = new int[3] { 1, 2, 3 };
             jx[1] = new int[2] { 4, 5 };
             jx[2] = new int[5] { 6, 7, 8, 9, 10 };
             jx[3] = new int[1] { 11 };

             int r = 0, c;
             while (r < jx.Length)
             {
                 c = 0;
                 while (c < jx[r].Length)
                 {
                     Console.Write("{0} ", jx[r][c]);
                     c++;
                 }
                 Console.WriteLine();
                 r++;
             }
         }*/
        }
    }


//System.out.println();
//System.out.print();
//Console.Write("Welcome to Fall Semester\n");
//Console.WriteLine("Welcome to C# class");

//string v1 = Console.ReadLine();
///Console.WriteLine("Output: " + v1);
//printf("%d", v2);
//Console.WriteLine("Output: {0}", v1);

//int a = 10, b = 20, c = 30;
//string t = "hello";
//Console.WriteLine("a:{2},b:{1},c:{2}{0}", a, b, c);
//Console.WriteLine("{0},{1}", b, t);

//float p = 9.88f;
//double q = 9.2;
//decimal r = 7.5M;

//string r1 = Console.ReadLine();
//int t1 = Convert.ToInt32(r1);
//int t2 = Int32.Parse(r1);
//int r2 = Convert.ToInt32(Console.ReadLine());

//byte p = 23;
//int e = p;

//short r = 8;
//p = (byte)r;