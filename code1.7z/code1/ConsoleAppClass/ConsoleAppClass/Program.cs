﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s1 = new Student();
            s1.SetId(1); //s1.id = 1;
            s1.SetName("Bruce"); //s1.name = "Bruce";
            s1.SetBloodGroup("B+"); //s1.bloodGroup = "B+";
            s1.SetAddress(new AddressFormat(1, 2, 1229, "Khulna")); //s1.address = new AddressFormat(1, 2, 1229, "Khulna");
            s1.SetCgpa(6.11); //s1.cgpa = 3.11;
            s1.ShowStudentInfo();
            //Console.WriteLine("{0}", s1.GetName());//s1.name);

            AddressFormat a1 = new AddressFormat(3, 22, 1249, "Sylhet");
            Student s2 = new Student(2, "Clerk", "AB+", a1, -3.22);
            s2.ShowStudentInfo();

            Student s3 = new Student(3, "Diana", "A+", new AddressFormat(32, 122, 1249, "Bogura"), 3.73);
            s3.ShowStudentInfo();
        }
    }
}
